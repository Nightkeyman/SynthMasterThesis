
#include "DaneDSP.h"

/*
void fDaneDSP(StrDaneDSP *D_DSP)
{
	D_DSP->numbParams = numbParamsConst;
	D_DSP->rozmKomunik = rozmKomunikConst;
	D_DSP->daneClassSize = sizeof(StrDaneDSP);

}
*/
